
#include "unity.h"

	void setUp()
	{	}
	void tearDown()
	{	}

	void test_typingtutor(void)
	{
    TEST_PASS_MESSAGE("PASS");
	}
	void test_typingtutor(void)
	{
    TEST_PASS_MESSAGE("PASS");
	}

	int test_main(void)
	{
	  	UNITY_BEGIN();

	  	RUN_TEST(test_typingtutor);
		RUN_TEST(test_typingtutor);

  		return UNITY_END();
	}
