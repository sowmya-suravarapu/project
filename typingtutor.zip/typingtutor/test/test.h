#ifndef TEST_typingtutor_H_INCLUDED
#define TEST_typingtutor_H_INCLUDED

int test_main(void);

#endif
